<?php
$Voornaam = $_POST["Voornaam"];
$Tussenvoegsel = $_POST["Tussenvoegsel"];
$Achternaam = $_POST["Achternaam"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=], initial-scale=1.0">
    <title>Top Gear NL</title>
    <link rel="stylesheet" href="bedanktstyle.php">
</head>
<body>

<?php
    include('core/header.php');
?>

<div id="Voornaam"> 
<?php echo "<h1 style='color: white; font-family: Arial, Helvetica, sans-serif; font-weight: bold; margin-top: 150px; margin-left: 35px;'>
Bedankt $Voornaam $Tussenvoegsel $Achternaam voor het bestellen van ons product!</h1>"; ?>
</div>

 <!-- dit is de Footer met copyright -->
<div id="f1">
    <h3 id="text1"> Copyright © 2022 BBC. The BBC is not responsible for the content of external sites. Read about our approach to external linking. </h3>
</div>

</body>
</html>