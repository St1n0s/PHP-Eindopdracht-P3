<!DOCTYPE html>
<html>
<head>

</head>
<body>

<h1 style="text-align: center; font-family: sans-serif;">Category</h1>

<?php
include("../core/db_connect.php");

$sql = "SELECT * FROM category";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Merk</th><th>Model</th><th>Kleur</th>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["category_id"]. "</td><td>" . $row["merk"]. "</td><td>" . $row["model"]. "</td><td>" . $row["kleur"]. "</td><td><a href='category_delete.php?category_id=".$row["category_id"]."'>Delete</a></td><td><a href='category_update.php?category_id=".$row["category_id"]."'>Edit</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$con->close();
?>

</body>
</html>
