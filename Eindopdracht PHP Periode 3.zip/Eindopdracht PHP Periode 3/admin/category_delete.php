<?php
    include('../core/db_connect.php');

    $category_id = $_GET["category_id"];

    $sql = "DELETE FROM category WHERE category_id = ".$category_id."";
    $result = $con->query($sql);

    header("Location: category_read.php");
?>