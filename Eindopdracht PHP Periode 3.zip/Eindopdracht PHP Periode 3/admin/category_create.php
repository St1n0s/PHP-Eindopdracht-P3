<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db_name = "eindopdracht_web_p2";

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $sql = "INSERT INTO category (merk, model, kleur) VALUES ('".$_POST["merk"]."','".$_POST["model"]."','".$_POST["kleur"]."')";
   
    if ($conn->query($sql) === TRUE) {
      echo "New record created successfully";
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top Gear NL</title>
</head>
<body>
    <form method="POST"> 
        <div> 
            <input type="text" name="merk" placeholder="merk">
            <input type="text" name="model" placeholder="model">
            <input type="text" name="kleur" placeholder="kleur">
            <input type="submit" name="submit" value="submit">
        </div>
    </form>  
</body>
</html>