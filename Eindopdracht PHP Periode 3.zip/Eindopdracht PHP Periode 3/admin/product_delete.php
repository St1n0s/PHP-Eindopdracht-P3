<?php
    include('../core/db_connect.php');

    $product_id = $_GET["product_id"];

    $sql = "DELETE FROM product WHERE product_id = ".$product_id."";
    $result = $con->query($sql);

    header("Location: product_read.php");
?>