<?php
    include('../core/db_connect.php');

    $users_id = $_GET["users_id"];

    $sql = "DELETE FROM users WHERE users_id = ".$users_id."";
    $result = $con->query($sql);

    header("Location: users_read.php");
?>