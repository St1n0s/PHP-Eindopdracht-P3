<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db_name = "eindopdracht_web_p2";

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

$category_id = $_GET["category_id"];
echo $category_id;

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $sql = "UPDATE category SET merk='{$_POST['merk']}', model= '{$_POST['model']}', kleur= '{$_POST['kleur']}' WHERE category_id = ".$category_id."";
   
    if ($conn->query($sql) === TRUE) {
      echo "New record created successfully";
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top Gear NL</title>
</head>
<body>
    <form method="POST" action="category_update.php?category_id=<?php echo $category_id; ?>" enctype="multipart/form-data"> 
        <div> 
            <input type="text" name="merk" placeholder="merk">
            <input type="text" name="model" placeholder="model">
            <input type="text" name="kleur" placeholder="kleur">
            <input type="submit" name="submit" value="submit">
        </div>
    </form>  
</body>
</html>