<!DOCTYPE html>
<html>
<head>

</head>
<body>

<h1 style="text-align: center; font-family: sans-serif;">Products</h1>

<?php
include("../core/db_connect.php");

$sql = "SELECT * FROM product";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Kracht</th><th>Koppel</th><th>Capaciteit</th><th>Transmissie</th><th>Zitplaatsen</th><th>Brandstof</th><th>Prijs</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["product_id"]. "</td><td>" . $row["kracht"]. "</td><td>" . $row["koppel"]. "</td><td>" . $row["capaciteit"]. "</td><td>" . $row["transmissie"]. "</td><td>" . $row["zitplaatsen"].  "</td><td>" . $row["brandstof"]. "</td><td>" . $row["prijs"]. "</td><td><a href='product_delete.php?product_id=".$row["product_id"]."'>Delete</a></td><td><a href='product_update.php?product_id=".$row["product_id"]."'>Edit</a></td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$con->close();
?>

</body>
</html>
