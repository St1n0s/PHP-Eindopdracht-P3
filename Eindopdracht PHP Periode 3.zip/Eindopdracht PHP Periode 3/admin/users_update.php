<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db_name = "eindopdracht_web_p2";

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

$users_id = $_GET["users_id"];
echo $users_id;

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $sql = "UPDATE users SET username='{$_POST['username']}', `password`= '{$_POST['password']}', created_at= '{$_POST['created_at']}' WHERE users_id = ".$users_id."";
   
    if ($conn->query($sql) === TRUE) { 
      echo "New record created successfully";
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top Gear NL</title>
</head>
<body>
    <form method="POST" action="users_update.php?users_id=<?php echo $users_id; ?>" enctype="multipart/form-data"> 
        <div> 
            <input type="text" name="username" placeholder="username">
            <input type="text" name="password" placeholder="password">
            <input type="text" name="created_at" placeholder="created_at">
            <input type="submit" name="submit" value="submit">
        </div>
    </form>  
</body>
</html>