<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db_name = "eindopdracht_web_p2";

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

$product_id = $_GET["product_id"];
echo $product_id;
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $sql = "UPDATE product SET prijs='{$_POST['prijs']}', kracht= '{$_POST['kracht']}', koppel= '{$_POST['koppel']}', capaciteit= '{$_POST['capaciteit']}', transmissie= '{$_POST['transmissie']}', zitplaatsen= '{$_POST['zitplaatsen']}', brandstof= '{$_POST['brandstof']}' WHERE product_id = ".$product_id."";
   
    if ($conn->query($sql) === TRUE) {
      echo "New record created successfully";
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top Gear NL</title>
</head>
<body>
    <form method="POST" action="product_update.php?product_id=<?php echo $product_id; ?>" enctype="multipart/form-data"> 
        <div> 
            <input type="text" name="prijs" placeholder="prijs">
            <input type="text" name="kracht" placeholder="kracht">
            <input type="text" name="koppel" placeholder="koppel">
            <input type="text" name="capaciteit" placeholder="capaciteit" >
            <input type="text" name="transmissie" placeholder="transmissie">
            <input type="text" name="zitplaatsen" placeholder="zitplaatsen"> 
            <input type="text" name="brandstof" placeholder="brandstof">
            <input type="submit" name="submit" value="submit">
        </div>
    </form>  
</body>
</html>