<!DOCTYPE html>
<html>
<head>

</head>
<body>

<h1 style="text-align: center; font-family: sans-serif;">Users</h1>

<?php
include("../core/db_connect.php");

$sql = "SELECT * FROM users";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Username</th><th>Password</th><th>Date</th>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["users_id"]. "</td><td>" . $row["username"]. "</td><td>" . $row["password"]. "</td><td>" . $row["created_at"]. "</td><td><a href='users_delete.php?users_id=".$row["users_id"]."'>Delete</a></td><td><a href='users_update.php?users_id=".$row["users_id"]."'>Edit</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$con->close();
?>

</body>
</html>
