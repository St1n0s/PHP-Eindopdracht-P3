<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top Gear NL</title>
    <link rel="stylesheet" href="http://localhost/webdev-base-webshop-main/assets/css/home.css">
    
<?php
    include('core/header.php');
?>

<!-- Dit is de sidebar waar je de kleur kiest -->
<div id="h2">
   <div id="kleur123">Kleur</div>

   <div><input type="radio" id="rood" name="Rood" value="Rood">
   <label for="Rood" id="rgbg">Rood</label></div>

   <div><input type="radio" id="groen" name="Groen" value="Groen">
   <label for="Groen" id="rgbg">Groen</label></div>

   <div><input type="radio" id="blauw" name="Blauw" value="Blauw">
   <label for="Blauw" id="rgbg">Blauw</label></div>
   
   <div><input type="radio" id="geel" name="Geel" value="Geel">
   <label for="Geel" id="rgbg">Geel</label></div>  
</div>   

<!-- Dit id de sidebar waar je de prijs kiest -->
<div id="h3">
   <div id="kleur123">Prijs</div>
   <input type="text" id="minmax" name="Min" placeholder="$ 0,00">
   <label for="Min" id="mm">Min</label>
   <input type="text" id="minmax" name="Max" placeholder="$ 14.000,00">
   <label for="Min" id="mm">Max</label>
</div>

<!-- Dit is de sidebar waar je je kan opgeven voor de nieuwsbrief -->
<div id="h4">
   <div id="kleur123">Nieuwsbrief</div>
   <input type="text" id="mail" name="mail" placeholder="Vul hier je E-mail in">
</div>

<!-- Dit is de sidebar waar de functie van de meme wordt uitgevoerd doormiddel van een button -->
<div id="meme">
    <p id="kleur123">Klik hier voor de Dacia Sandero meme</p>
    <button onclick="oh_no()" id="btn2">Klik hier</button>
</div>



<!-- Hier staan de 20 producten -->
<div id="Dacia1">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia2">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia3">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
    
</div>

<div id="Dacia4">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia5">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia6">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia7">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia8">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia9">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia10">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia11">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia12">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia13">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia14">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia15">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia16">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia17">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia18">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia19">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

<div id="Dacia20">
    <img src="assets/img/Dacia.jpeg">
    <p id="d1">Dacia Sandero</p>
    <p id="p1">Prijs: $9.999</p>
    <a href="detailpagina.php"><input type="button" id="btn" name="Kopen" value="Kopen"></a>
</div>

</form>

<div id="f1">
    <h3 id="txt1"> Copyright © 2022 BBC. The BBC is not responsible for the content of external sites. Read about our approach to external linking. </h3>
</div>

</body>
</html>