<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top Gear NL</title>
    <link rel="stylesheet" href="http://localhost/webdev-base-webshop-main//assets/css/bestel.css">
    
    <!-- VENSTER OPENEN OP 80% VOOR BESTE RESULTAAT -->
   
    
<?php
    include('core/header.php');
?>

 <!-- Dit is de div met input-velden -->
 <div id="h2">
     <big><p id="t1">Bestel Formulier</p></big>
<form action="bedankt.php" method="post"> 
    <label for="Voornaam" id="l1">Voornaam*</label>
    <input type="text" id="txt1" name="Voornaam" placeholder="Voornaam*" required>

    <label for="Tussenvoegsel" id="l2">Tussenvoegsel</label>
    <input type="text" class="text" name="Tussenvoegsel" placeholder="Tussenvoegsel">

    <label for="Achternaam" id="l3">Achternaam*</label>
    <input type="text" class="text" name="Achternaam" placeholder="Achternaam*" required>

    <label for="Straat en Huisnummer" id="l4">Adress*</label>
    <input type="text" class="text" name="Straat en Huisnummer" placeholder="Adress*" required>

    <label for="Postcode" id="l5">Postcode*</label>
    <input type="text" class="text" name="Postcode" placeholder="Postcode*" required>

    <label for="Telefoonnummer" id="l7">Telefoonnummer</label>
    <input type="text" class="text" name="Telefoonnummer" placeholder="Telefoonnummer">
    
    <label for="Email" id="l8">Email*</label>
    <input type="email" class="text" name="Email" placeholder="Email*">

    <label for="Rekening" id="l9">Rekening*</label>
    <input type="text" class="text" name="Rekening" placeholder="Rekening*">
 
    <a href="bedankt.php"><input type="submit" id="btn1" name="Bestel" value="Bestel"></a>
</form>
</div>

<!-- dit is de Footer met copyright -->
<div id="f1">
    <h3 id="text1"> Copyright © 2022 BBC. The BBC is not responsible for the content of external sites. Read about our approach to external linking. </h3>
</div>



   
</body>
</html>