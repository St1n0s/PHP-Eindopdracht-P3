<!-- dit is de Footer met copyright -->
<div id="f1">
    <h3 id="txt1"> Copyright © 2022 BBC. The BBC is not responsible for the content of external sites. Read about our approach to external linking. </h3>
</div>
    
</body>
</html>
<?php
    $con->close();
?>