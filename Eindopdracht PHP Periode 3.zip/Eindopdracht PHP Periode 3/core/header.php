

<?php
    include('core/db_connect.php');
?>
    <!-- Hier staat de functie voor de meme in de sidebar -->
    <script>
        function oh_no(){
            window.open("https://youtu.be/9S8eNZ4fw5I");
        }
    </script>

</head>
<body>


 <!-- Dit is de header -->
<div id="h1">
   <img src="assets/img/topgearlogo.png">
   <a href="http://localhost/webdev-base-webshop-main/tg_mainpage.php"><input type="button" id="home" name="home" value="Home"></a>
   <a href="http://localhost/webdev-base-webshop-main/detailpagina.php"><input type="button" id="auto" name="auto's" value="Koop hier de nieuwe Dacia Sandero!"></a>
   <a href="http://localhost/webdev-base-webshop-main/logout.php"><input type="button" id="logout" name="logout" value="Logout"></a>
</div>