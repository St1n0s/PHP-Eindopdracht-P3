<?php
header ("Content-Type: text/css");
?>

*{
    margin: 0;
    padding: 0;
}

/* Dit is de styling van de body en background image */
body{
    background-color: black;
    background-image: url(https://www.topgear.com/sites/default/files/images/news-article/2017/09/22e4b669a50bacd59e5424a65f23f724/tg300.jpg);
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: 100% 100%;
}

/* Dit is de styling van de header */
#h1{
    width: auto;
    height: 80px;
    background-color: black;
    border-radius: 3px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.5), 0 4px 8px 0 rgba(0, 0, 0, 0.3);
}

/* Dit is de styling van het logo*/
#h1 img{
    height: 75px;
    width: 150px;
    margin-top: 1px;
    margin-left: 4px;
    float: left;
}

/* Dit is de styling van de home knop in de header*/
#home{
    height: 50px;
    width: 150px;
    background-color: black;
    color: white;
    margin-left: 50px;
    margin-top: 15px;
    float: left;
    font-weight: bold;
    border: 2px solid white;
    border-radius: 10px;
    font-family: Arial, Helvetica, sans-serif;
}

#home:hover{
    height: 50px;
    width: 150px;
    background-color: white;
    color: black;
    margin-left: 50px;
    margin-top: 15px;
    float: left;
    font-weight: bold;
    border: 2px solid black;
    border-radius: 10px;
    font-family: Arial, Helvetica, sans-serif;
}

/* Dit is de styling van de dacia sandero knop in de header */
#auto{
    height: 50px;
    width: 250px;
    background-color: black;
    color: white;
    margin-left: 50px;
    margin-top: 15px;
    font-weight: bold;
    border: 2px solid white;
    border-radius: 10px;
    font-family: Arial, Helvetica, sans-serif;
}

#auto:hover{
    height: 50px;
    width: 250px;
    background-color: white;
    color: black;
    margin-left: 50px;
    margin-top: 15px;
    font-weight: bold;
    border: 2px solid black;
    border-radius: 10px;
    font-family: Arial, Helvetica, sans-serif;
}

#logout{
    height: 50px;
    width: 150px;
    background-color: black;
    color: white;
    margin-left: 50px;
    margin-top: 15px;
    float: left;
    font-weight: bold;
    border: 2px solid white;
    border-radius: 10px;
    font-family: Arial, Helvetica, sans-serif;
}

#logout:hover{
    height: 50px;
    width: 150px;
    background-color: white;
    color: black;
    margin-left: 50px;
    margin-top: 15px;
    float: left;
    font-weight: bold;
    border: 2px solid black;
    border-radius: 10px;
    font-family: Arial, Helvetica, sans-serif;
}

/* Dit is de styling van de footer */
#f1{
    width: auto;
    height: 80px;
    border-radius: 3px;
    background-color: black;
    color: white;
    margin-top: 310px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.5), 0 4px 8px 0 rgba(0, 0, 0, 0.3);
}

#text1{
    padding-top: 30px;
    margin-left: 5px;
    font-weight: bold;
    font-family: Arial, Helvetica, sans-serif;
}

#Voornaam{
    background-color: black;
    border: 2px solid white;
    border-radius: 10px;
    height: 400px;
    width: 700px;
    margin-left: 550px;
    margin-top: 250px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.5), 0 4px 8px 0 rgba(0, 0, 0, 0.3);
}
