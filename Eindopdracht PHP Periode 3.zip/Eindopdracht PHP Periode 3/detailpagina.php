<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top Gear NL</title>
    <link rel="stylesheet" href="http://localhost/webdev-base-webshop-main//assets/css/detail.css">

<?php
    include('core/header.php');
?>

<!-- Dit is de div voor het detail van het product -->
<div id="h2">
    <img src="assets/img/Dacia.jpeg" id="img1">
    <img src="assets/img/Dacia.jpeg" id="img2">
    <img src="assets/img/Dacia.jpeg" id="img3">
    <img src="assets/img/Dacia.jpeg" id="img4">
</div>

<!-- Dit is de code voor de info over het product -->
<div id="h2text">
<big><p id="p1">Kracht =	92 - 102 hp</p></big>
<big><p id="p2">Koppel =	107 Nm</p></big>
<big><p id="p3">Capaciteit benzinetank =	50 L</p></big>
<big><p id="p4">Transmissie =	Handgeschakeld</p></big>
<big><p id="p5">Zitplaatsen =	5</p></big>
<big><p id="p6">Type brandstof =	Benzine</p></big>
</div>

<!-- Dit is de code voor de button om het product te kopen -->
<div>
    <a href="bestel.php"><input type="button" id="btn1" name="Kopen" value="Kopen"></a>
</div>
    
<!-- dit is de Footer met copyright -->
<div id="f1">
    <h3 id="txt1"> Copyright © 2022 BBC. The BBC is not responsible for the content of external sites. Read about our approach to external linking. </h3>
</div>
 
   </form>
</body>
</html>