Dit is mijn eindopdracht voor PHP voor periode 3
in de map database staat het bestand voor de database
in admin map zitten de admin bestanden
de rest spreekt wel voor zich