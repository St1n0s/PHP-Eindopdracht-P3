
<?php

// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: tg_mainpage.php");
    exit;
}
 
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Vul je gebruikersnaam in.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Vul je wachtwoord in.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT users_id, username, password FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $users_id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["users_id"] = $users_id;
                            $_SESSION["username"] = $username;                            
                            
                            // Redirect user to welcome page
                            header("location: tg_mainpage.php");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Fout wachtwoord of gebruikersnaam.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Fout wachtwoord of gebruikersnaam.";
                }
            } else{
                echo "Oops! Er ging iets fout. Probeer het later nog een keer.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Top Gear NL</title>
    <link rel="stylesheet" href="http://localhost/webdev-base-webshop-main//assets/css/login.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <div id="login">
        <h1 id="l1">Login</h1>
        <p id="p1">Vul alsjeblieft je gegevens in om in te loggen.</p>

        <?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div id="gb">
                <h2>Gebruikersnaam</h2>
                <input type="text" name="username" id="gbip" <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?> value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>    
            <div id="ww">
                <h2 id="wwtxt">Wachtwoord</h2>
                <input type="password" name="password" id="wwip" <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>>
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div id="smbt">
                <input type="submit" id="submit" value="Login">
            </div>
            <p id="reg">Geen account? <a href="register.php">Registreer hier nu</a>.</p>
        </form>
    </div>

    <div id="f1">
       <h3 id="txt1"> Copyright © 2022 BBC. The BBC is not responsible for the content of external sites. Read about our approach to external linking. </h3>
    </div>

</body>
</html>